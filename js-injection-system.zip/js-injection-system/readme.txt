# JS Injection System

This system allows you to remotely inject JavaScript code into a web page. It consists of two parts:
- **Backend**: A Node.js server that serves remote JavaScript files.
- **Frontend**: A simple HTML page that injects JavaScript files.

## Setup and Usage

1. Clone the repository.
2. Install backend dependencies:
    ```bash
    cd backend
    npm install
    ```
3. Start the backend server:
    ```bash
    npm start
    ```
   The server will run on `http://localhost:3000`.

4. Open the `frontend/index.html` in your browser. The page will automatically inject the remote JavaScript from the backend server.

## Security

Be aware of potential security risks when injecting JavaScript remotely. Ensure that only trusted sources can serve and inject scripts.
